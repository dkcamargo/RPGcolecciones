public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Testing Personaje");
        new TestPersonaje().ejecutarTests();
    }
}
